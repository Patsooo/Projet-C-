#include "modifier.h"
#include "ui_modifier.h"

modifier::modifier(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::modifier)
{
    ui->setupUi(this);
}

modifier::~modifier()
{
    delete ui;
}


evenement modifier::on_buttonBox_accepted()
{
    QString nom = ui->nom->text();
    QString id= ui->id->text();
    QString lieux= ui->lieux->text();
    evenement e(id,nom,lieux);


    return e;
}
