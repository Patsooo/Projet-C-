#ifndef MODIFIER_H
#define MODIFIER_H
#include"evenement.h"
#include <QDialog>

namespace Ui {
class modifier;
}

class modifier : public QDialog
{
    Q_OBJECT

public:
    explicit modifier(QWidget *parent = nullptr);
    ~modifier();

public slots:
    evenement on_buttonBox_accepted();

private:
    Ui::modifier *ui;

};

#endif // MODIFIER_H
