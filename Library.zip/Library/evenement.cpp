#include "evenement.h"

evenement::evenement()
{

}
evenement::evenement(QString id ,QString nom ,QString lieux)
{
    this->nom=nom;
    this->lieux=lieux;
    this->id=id;
}
bool evenement::ajouter()
{
    QSqlQuery query;
    query.prepare("INSERT INTO evenement (id,nom,lieux) "
                        "VALUES (:id , :nom , :lieux )");
    query.bindValue(":id", id);
    query.bindValue(":nom", nom);
    query.bindValue(":lieux", lieux);
    return query.exec();
}
QSqlQueryModel * evenement::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from evenement");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("lieux"));
    return model;
}
bool evenement::supprimer(QString id)
{
QSqlQuery query;

query.prepare("Delete from evenement where id = :id ");
query.bindValue(":id", id);
return    query.exec();
}
bool evenement::modifier(QString x)
{
QSqlQuery query;

query.prepare("update evenement set id = :id ,nom = :nom ,lieux = :l  where id = :x ");
query.bindValue(":x", x);
query.bindValue(":id", id);
query.bindValue(":nom", nom);
query.bindValue(":l", lieux);

return    query.exec();
}
QSqlQueryModel * evenement::recherche(QString valeur )
{
 QSqlQueryModel * model = new QSqlQueryModel() ;
 QSqlQuery query;
query.prepare("SELECT * FROM evenement WHERE nom like :valeur order by nom ");
 valeur="%"+valeur+"%";
 query.bindValue(":valeur",valeur);
 query.exec();
 model->setQuery(query);
 model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
 model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
 model->setHeaderData(2, Qt::Horizontal, QObject::tr("lieux"));
 return  model;
}
QSqlQueryModel * evenement::tri_c()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from evenement ORDER BY id ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("lieux"));

    return model;
}
QSqlQueryModel * evenement::tri_d()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from evenement ORDER BY id DESC");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("lieux"));

    return model;
}
