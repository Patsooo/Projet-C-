#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"evenement.h"
#include<QMessageBox>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->comboBox->addItem("afficher");
    ui->comboBox->addItem("trier date ordre croissant");
    ui->comboBox->addItem("trier date ordre decroissant");
    ui->tableView->setModel(tmpevenement.afficher());
    ui->tableView_5->setModel(tmpevenement.afficher());
    connect(ui->sendBtn, SIGNAL(clicked()),this, SLOT(sendMail()));
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_pushButton_clicked()
{
    QString nom = ui->nom->text();
    QString lieux= ui->lieux->text();
    QString id= ui->id->text();
    evenement e(id,nom,lieux);
    bool test=e.ajouter ();
    if(test)
  {ui->tableView->setModel(tmpevenement.afficher());//refresh
         ui->tableView_5->setModel(tmpevenement.afficher());
  QMessageBox::information(nullptr, QObject::tr("Ajouter un evenement"),
                    QObject::tr("evenement ajouté.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

  }
    else
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un evenement"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_comboBox_currentIndexChanged(int index)
{
    if(index==0)
    {
        ui->tableView->setModel(tmpevenement.afficher());
    }
    if(index==1)
    {
        ui->tableView->setModel(tmpevenement.tri_c());
    }
    if(index==2)
    {
        ui->tableView->setModel(tmpevenement.tri_d());
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    QString numr = ui->sup->text();
    bool test=tmpevenement.supprimer(numr);
    if(test)
    {ui->tableView->setModel(tmpevenement.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un evenement"),
                    QObject::tr("evenement supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un evenement"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pushButton_3_clicked()
{
    modifier m ;
    m.setModal(true);
    m.exec();
    QString x = ui->mod->text();
    evenement e=m.on_buttonBox_accepted();
    bool test=e.modifier(x);
    if(test)
    {ui->tableView->setModel(tmpevenement.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("modifier un evenement"),
                    QObject::tr("evenement vous trouvé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("!!!!!!!!!!!"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}
void MainWindow::on_lineEdit_textChanged(const QString &arg1)
{

     ui->tableView_5->setModel(tmpevenement.recherche(arg1));
}

void MainWindow::sendMail()
{
    Smtp* smtp = new Smtp("dhia.benamor@esprit.tn","181JMT1776", "smtp.gmail.com",465);
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));


    smtp->sendMail("dhia.benamor@esprit.tn", ui->rcpt->text() , ui->subject->text(),ui->msg->toPlainText());
}

void MainWindow::mailSent(QString status)
{
    if(status == "Message sent")
        QMessageBox::warning( nullptr, tr( "Qt Simple SMTP client" ), tr( "Message sent!\n\n" ) );
}
