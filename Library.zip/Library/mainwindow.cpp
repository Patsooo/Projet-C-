#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"evenement.h"
#include<QMessageBox>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->comboBox->addItem("afficher");
    ui->comboBox->addItem("trier id ordre croissant");
    ui->comboBox->addItem("trier id ordre decroissant");
    ui->comboBox_2->addItem("afficher");
    ui->comboBox_2->addItem("trier id ordre croissant");
    ui->comboBox_2->addItem("trier id ordre decroissant");
    ui->tableView->setModel(tmpevenement.afficher());
    ui->tableView_5->setModel(tmpevenement.afficher());
    ui->tableView_2->setModel(tmprdv.afficher());
    ui->tableView_6->setModel(tmprdv.afficher());
    connect(ui->sendBtn, SIGNAL(clicked()),this, SLOT(sendMail()));
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_pushButton_clicked()
{
    QString nom = ui->nom->text();
    QString lieux= ui->lieux->text();
    QString id= ui->id->text();
    evenement e(id,nom,lieux);
    bool test=e.ajouter ();
    if(test)
  {ui->tableView->setModel(tmpevenement.afficher());//refresh
         ui->tableView_5->setModel(tmpevenement.afficher());
  QMessageBox::information(nullptr, QObject::tr("Ajouter un événement"),
                    QObject::tr("événement ajouté.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

  }
    else
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un événement"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_comboBox_currentIndexChanged(int index)
{
    if(index==0)
    {
        ui->tableView->setModel(tmpevenement.afficher());
    }
    if(index==1)
    {
        ui->tableView->setModel(tmpevenement.tri_c());
    }
    if(index==2)
    {
        ui->tableView->setModel(tmpevenement.tri_d());
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    QString numr = ui->sup->text();
    bool test=tmpevenement.supprimer(numr);
    if(test)
    {ui->tableView->setModel(tmpevenement.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un événement"),
                    QObject::tr("événement supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un evenement"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pushButton_3_clicked()
{
    modifier m ;
    m.setModal(true);
    m.exec();
    QString x = ui->mod->text();
    evenement e=m.on_buttonBox_accepted();
    bool test=e.modifier(x);
    if(test)
    {ui->tableView->setModel(tmpevenement.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("modifier un événement"),
                    QObject::tr("événement vous trouvé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("!!!!!!!!!!!"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}
void MainWindow::on_lineEdit_textChanged(const QString &arg1)
{

     ui->tableView_5->setModel(tmpevenement.recherche(arg1));
}

void MainWindow::sendMail()
{
    Smtp* smtp = new Smtp("dhia.benamor@esprit.tn","181JMT1776", "smtp.gmail.com",465);
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));


    smtp->sendMail("dhia.benamor@esprit.tn", ui->rcpt->text() , ui->subject->text(),ui->msg->toPlainText());
}

void MainWindow::mailSent(QString status)
{
    if(status == "Message sent")
        QMessageBox::warning( nullptr, tr( "Qt Simple SMTP client" ), tr( "Message sent!\n\n" ) );
}
void MainWindow::on_pushButton_4_clicked()
{
    QString nom = ui->nom->text();
    QString prenom= ui->prenom->text();
    QDateTime dater=ui->date->dateTime();

    QString cin= ui->cin->text();

    QString mail= ui->mail->text();
    QString numr= ui->numr->text();
    RDV r(nom , prenom ,dater   ,cin   ,numr,mail);
    bool test=r.ajouter ();
    if(test)
  {ui->tableView_2->setModel(tmprdv.afficher());//refresh
         ui->tableView_5->setModel(tmprdv.afficher());
  QMessageBox::information(nullptr, QObject::tr("Ajouter un rendez_vous"),
                    QObject::tr("Rendez_vous ajouté.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

  }
    else
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un rendez_vous"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pushButton_5_clicked()
{
    QString numr = ui->sup_2->text();
    bool test=tmprdv.supprimer(numr);
    if(test)
    {ui->tableView_2->setModel(tmprdv.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un rendez_vous"),
                    QObject::tr("Rendez_vous supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un rendez_vous"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pushButton_6_clicked()
{
    QString nom = ui->nom_3->text();
    QString prenom= ui->prenom_2->text();
    QDateTime dater=ui->date_2->dateTime();

    QString cin= ui->cin_2->text();

    QString mail= ui->mail_2->text();
    QString numr= ui->numr_2->text();
    RDV r(nom , prenom ,dater   ,cin   ,numr,mail);
    bool test=r.modifier ();
    if(test)
  {ui->tableView_2->setModel(tmprdv.afficher());//refresh
         ui->tableView_5->setModel(tmprdv.afficher());
  QMessageBox::information(nullptr, QObject::tr("Modifier un rendez_vous"),
                    QObject::tr("Rendez_vous modifié.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

  }
    else
        QMessageBox::critical(nullptr, QObject::tr("Modifier un rendez_vous"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}



void MainWindow::on_comboBox_2_currentIndexChanged(int index)
{
    if(index==0)
    {
        ui->tableView->setModel(tmprdv.afficher());
    }
    if(index==1)
    {
        ui->tableView->setModel(tmprdv.tri_c());
    }
    if(index==2)
    {
        ui->tableView->setModel(tmprdv.tri_d());
    }
}
void MainWindow::on_lineEdit_2_textChanged(const QString &arg1)
{
     ui->tableView_6->setModel(tmprdv.recherche(arg1));
}

