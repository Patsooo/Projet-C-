#include "rdv.h"

RDV::RDV()
{

}
RDV::RDV(QString nom ,QString prenom ,QDateTime dater   ,QString cin   ,QString numr,QString mail)
{
    this->nom=nom;
    this->prenom=prenom;
    this->dater=dater;
     this->cin=cin;
     this->numr=numr;
    this->mail=mail;
}
bool RDV::ajouter()
{
    QSqlQuery query;
    query.prepare("INSERT INTO rdv (numr,dater,nom,prenom ,cin,mail ) "
                        "VALUES (:nu , :d , :n , :p   , :cin , :m  )");
    query.bindValue(":nu", numr);
    query.bindValue(":d", dater);
    query.bindValue(":n", nom);
    query.bindValue(":p", prenom);

    query.bindValue(":cin", cin);
    query.bindValue(":m", mail);

    return query.exec();
}
QSqlQueryModel * RDV::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from rdv");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("numrdv"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("date"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("prenom"));

model->setHeaderData(4, Qt::Horizontal, QObject::tr("cin"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("mail"));


    return model;
}
bool RDV::supprimer(QString numr)
{
QSqlQuery query;

query.prepare("Delete from rdv where numr = :nu ");
query.bindValue(":nu", numr);
return    query.exec();
}
bool RDV::modifier( )
{
QSqlQuery query;

query.prepare("update rdv set dater = :d ,nom = :n ,prenom = :p  ,cin = :cin ,mail = :m  where numr = :nu ");

query.bindValue(":nu", numr);
query.bindValue(":d", dater);
query.bindValue(":n", nom);
query.bindValue(":p", prenom);

query.bindValue(":cin", cin);
query.bindValue(":m", mail);

return    query.exec();
}
QSqlQueryModel * RDV::recherche(QString valeur )
{
 QSqlQueryModel * model = new QSqlQueryModel() ;
 QSqlQuery query;
query.prepare("SELECT * FROM rdv WHERE nom like :valeur order by nom ");
 valeur="%"+valeur+"%";
 query.bindValue(":valeur",valeur);
 query.exec();
 model->setQuery(query);
 model->setHeaderData(0, Qt::Horizontal, QObject::tr("numrdv"));
 model->setHeaderData(1, Qt::Horizontal, QObject::tr("date"));
 model->setHeaderData(2, Qt::Horizontal, QObject::tr("nom"));
 model->setHeaderData(3, Qt::Horizontal, QObject::tr("prenom"));
 model->setHeaderData(4, Qt::Horizontal, QObject::tr("cin"));
 model->setHeaderData(5, Qt::Horizontal, QObject::tr("mail"));

 return  model;
}
QSqlQueryModel * RDV::tri_c()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from rdv ORDER BY dater ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("numrdv"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("date"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("prenom"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("cin"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("mail"));

    return model;
}
QSqlQueryModel * RDV::tri_d()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from rdv ORDER BY dater DESC");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("numrdv"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("date"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("prenom"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("cin"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("mail"));

    return model;
}
