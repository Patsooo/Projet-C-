#ifndef EVENEMENT_H
#define EVENEMENT_H
#include<QDateTime>
#include<QString>
#include<QSqlQueryModel>
#include<QSqlQuery>
class evenement
{

    QString nom ;
    QString id;
    QString  lieux ;

public:
    evenement();
    evenement(QString,QString,QString);
    bool ajouter();
    QSqlQueryModel * afficher();
    QSqlQueryModel * tri_c();
    QSqlQueryModel * tri_d();
    bool supprimer(QString);
    bool modifier(QString);
    QSqlQueryModel * recherche(QString valeur);

};

#endif // EVENEMENT_H
