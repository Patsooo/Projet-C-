#ifndef RDV_H
#define RDV_H
#include<QDateTime>
#include<QString>
#include<QSqlQueryModel>
#include<QSqlQuery>
class RDV
{
    QString nom ;
    QString prenom ;

    QDateTime dater;
    QString cin;

    QString numr;
    QString mail ;

public:
    RDV();
    RDV(QString,QString,QDateTime,QString,QString,QString);
    bool ajouter();
    QSqlQueryModel * afficher();
    QSqlQueryModel * tri_c();
    QSqlQueryModel * tri_d();
    bool supprimer(QString);
    bool modifier();
    QSqlQueryModel * recherche(QString valeur);


};

#endif // RDV_H
