#include "promotion.h"

promotion::promotion()
{

}
promotion::promotion(QString id,int score)
{
    this->id_promo = id;
    this->score = score;
}
bool promotion::ajouter_promo()
{
    QSqlQuery query;
    QString res= QString::number(score);

    query.prepare("INSERT INTO promotions (ID_promotion,score) "
                        "VALUES (:ID_promotion,:score)");

    query.bindValue(":ID_promotion", id_promo);
    query.bindValue(":score", res);
    return  query.exec();

}
bool promotion::supprimer_prom(QString idd)
{
    QSqlQuery query;
    query.prepare("Delete from promotions where ID_promotion = :id");
    query.bindValue(":id", idd);
    return    query.exec();
}
QSqlQueryModel * promotion::afficher_prom()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from promotions");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_promotions"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("score"));

    return model;
}
QSqlQueryModel * promotion::rechercher_pro(int a)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery query;
    QString res = QString::number(a);
    query.prepare("SELECT * FROM promotions where ID_promotion = :id");
    query.bindValue(":id",res);
    query.exec();
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_promotions"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("score"));
        return model;
}

