#include "gestiondocument.h"
#include "ui_gestiondocument.h"
#include <QMessageBox>
gestiondocument::gestiondocument(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::gestiondocument)
{
    ui->setupUi(this);
    ui->tabdoc_2->setModel(tmpdocuments.afficher_doc());
    ui->tabpromo->setModel(tmpromotions.afficher_prom());
    ui->tabdoc->setModel(tmpdocuments.afficher_doc());
    QDate d;
    QRegExp rx("[A-Za-z_]+");
    QRegExp rx1("[0-9_.]+");
    QValidator *v1 = new QRegExpValidator(rx,this);
    QValidator *v2 = new QRegExpValidator(rx1,this);
    ui->id->setValidator(v2);
    ui->type->setValidator(v1);
    ui->prix->setValidator(v2);
    ui->titre->setValidator(v1);
    ui->date->setDate(d.currentDate());
    ui->id_promo->setValidator(v2);
    ui->score->setValidator(v2);
}

gestiondocument::~gestiondocument()
{
    delete ui;
}

void gestiondocument::on_ajoute_doc_clicked()
{
    int ID = ui->id->text().toInt();
       QString TYPE= ui->type->text();
       QString TITRE= ui->titre->text();
       double PRIX = ui->prix->text().toDouble();
       QDate date =ui->date->date();
       documents d (ID,TYPE,TITRE,PRIX,date);
       bool test=d.ajouter_doc();

         if(test)
         {
               ui->tabdoc->setModel(tmpdocuments.afficher_doc());
               QMessageBox::information(nullptr, QObject::tr("Ajouter un document"),
                         QObject::tr("Document ajouté.\n"
                                     "Click Cancel to exit."), QMessageBox::Cancel);
         }
}

void gestiondocument::on_supprimer_doc_clicked()
{
    bool test = tmpdocuments.supprimer_doc(ui->tabdoc->model()->data(ui->tabdoc->currentIndex()).toString());
    ui->tabdoc->setModel(tmpdocuments.afficher_doc());
}



void gestiondocument::on_recherche_textEdited(const QString &arg1)
{
    ui->tabdoc->setModel(tmpdocuments.rechercher_dyn(arg1));
}

void gestiondocument::on_comboBox_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "TRI  PAR PRIX")
        ui->tabdoc->setModel(tmpdocuments.tri_doc());
    else if(arg1 == "TRI ALPHABETIQUE")
        ui->tabdoc->setModel(tmpdocuments.tri_alphabitekdoc());

}

void gestiondocument::on_pushButton_6_clicked()
{
      int ID = ui->id->text().toInt();
      QString TYPE= ui->type->text();
      QString TITRE= ui->titre->text();
      double PRIX = ui->prix->text().toDouble();
      QDate date = ui->date->date();
      documents d;

      bool test=d.modifier_doc(ID,TYPE,TITRE,PRIX,date);
      ui->tabdoc->setModel(tmpdocuments.afficher_doc());

}

void gestiondocument::on_ajouter_promo_clicked()
{
    int score = ui->score->text().toInt();
    QString id= ui->id_promo->text();

    promotion p (id,score);
    bool test=p.ajouter_promo();

      if(test)
      {
          ui->tabpromo->setModel(tmpromotions.afficher_prom());
            QMessageBox::information(nullptr, QObject::tr("Ajouter un promotiont"),
                      QObject::tr("promotion ajouté.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
      }
}

void gestiondocument::on_supprimer_promo_clicked()
{
    bool test = tmpromotions.supprimer_prom(ui->tabpromo->model()->data(ui->tabpromo->currentIndex()).toString());
    ui->tabpromo->setModel(tmpromotions.afficher_prom());
}



void gestiondocument::on_recherche_promo_clicked()
{
    int id = ui->a->text().toInt();
    ui->tabpromo->setModel(tmpromotions.rechercher_pro(id));
}
