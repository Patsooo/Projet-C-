#ifndef GESTIONDOCUMENT_H
#define GESTIONDOCUMENT_H

#include <QDialog>
#include "documents.h"
#include "promotion.h"
namespace Ui {
class gestiondocument;
}

class gestiondocument : public QDialog
{
    Q_OBJECT

public:
    explicit gestiondocument(QWidget *parent = nullptr);
    ~gestiondocument();

private slots:
    void on_ajoute_doc_clicked();

    void on_supprimer_doc_clicked();

    void on_recherche_textEdited(const QString &arg1);

    void on_comboBox_currentIndexChanged(const QString &arg1);

    void on_pushButton_6_clicked();

    void on_ajouter_promo_clicked();

    void on_supprimer_promo_clicked();

    void on_recherche_promo_clicked();

private:
    Ui::gestiondocument *ui;
    documents tmpdocuments;
    promotion tmpromotions;
};

#endif // GESTIONDOCUMENT_H
