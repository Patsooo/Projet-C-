#ifndef DOCUMENTS_H
#define DOCUMENTS_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDate>
class documents
{
protected:
    int ID_DOC ;
    QString Type_Doc ;
    QString Titre_Doc;
    double Prix_Doc ;
    QDate date;


public:
    documents();
    documents(int,QString,QString,double,QDate);
    bool ajouter_doc();
    QSqlQueryModel * afficher_doc();
    bool supprimer_doc(QString idd);
    bool modifier_doc(int idd,QString a,QString b,float c,QDate n);
    QSqlQueryModel * tri_doc();
    QSqlQueryModel * tri_alphabitekdoc();
    QSqlQueryModel * rechercher_doc(int a);
    QSqlQueryModel * rechercher_dyn(QString a);

};

#endif // DOCUMENTS_H
