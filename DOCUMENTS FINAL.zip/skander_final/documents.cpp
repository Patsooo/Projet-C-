#include "documents.h"

documents::documents()
{
ID_DOC=0;
Type_Doc="";
Titre_Doc="";
Prix_Doc=0;
}
documents::documents(int a,QString b,QString c ,double d,QDate n)
{
    this->ID_DOC=a;
    this->Type_Doc=b;
    this->Titre_Doc=c;
    this->Prix_Doc=d;
    this->date=n;
}
bool documents::ajouter_doc()
{
QSqlQuery query;
QString res= QString::number(ID_DOC);
QString res1= QString::number(Prix_Doc);
query.prepare("INSERT INTO DOCUMENTS (ID_DOCUMENT,TYPE_DOCUMENT,TITRE_DOCUMENT,PRIX,DATE_S) "
                    "VALUES (:ID_DOCUMENT,:TYPE_DOCUMENT,:TITRE_DOCUMENT,:PRIX,:DATE)");

query.bindValue(":ID_DOCUMENT", res);
query.bindValue(":TYPE_DOCUMENT", Type_Doc);
query.bindValue(":TITRE_DOCUMENT", Titre_Doc);
query.bindValue(":PRIX", res1);
query.bindValue(":DATE",date);

return    query.exec();
}
QSqlQueryModel * documents::afficher_doc()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from DOCUMENTS");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_DOCUMENT"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE_DOCUMENT"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TITRE_DOCUMENT"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("PRIX"));
    return model;
}
bool documents::supprimer_doc(QString idd)
{
    QSqlQuery query;
    query.prepare("Delete from DOCUMENTS where ID_DOCUMENT = :id");
    query.bindValue(":id", idd);
    return    query.exec();
}
bool documents::modifier_doc(int idd,QString a,QString b,float c,QDate n)
{
    QSqlQuery query;
    QString res= QString::number(idd);
    QString res1= QString::number(c);

    query.prepare("UPDATE DOCUMENTS SET  TYPE_DOCUMENT = :TYPE , TITRE_DOCUMENT = :TITRE, PRIX = :PRIX , DATE_S =:DATE WHERE ID_DOCUMENT = :ID");
    query.bindValue(":ID", res);
    query.bindValue(":TYPE", a);
    query.bindValue(":TITRE", b);
    query.bindValue(":PRIX", res1);
    query.bindValue(":DATE", n);

    return    query.exec();
}
QSqlQueryModel * documents::tri_doc()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("SELECT * FROM documents ORDER BY prix");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_DOCUMENT"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE_DOCUMENT"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TITRE_DOCUMENT"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("PRIX"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATE_S"));
    return model;
}
QSqlQueryModel * documents::rechercher_doc(int a)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery query;
    QString res = QString::number(a);
    query.prepare("SELECT * FROM DOCUMENTS where ID_DOCUMENT = :id");
    query.bindValue(":id",res);
    query.exec();
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_DOCUMENT"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE_DOCUMENT"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TITRE_DOCUMENT"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("PRIX"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATE_S"));
        return model;
}
QSqlQueryModel * documents::rechercher_dyn(QString a)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery query;
    query.prepare("SELECT * FROM DOCUMENTS where type_document like '"+a+"' || '%'");
    query.exec();
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_DOCUMENT"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE_DOCUMENT"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TITRE_DOCUMENT"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("PRIX"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATE_S"));
        return model;
}
QSqlQueryModel * documents::tri_alphabitekdoc()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery query;
    query.prepare("SELECT * FROM DOCUMENTS order by titre_document");
    query.exec();
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_DOCUMENT"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE_DOCUMENT"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("TITRE_DOCUMENT"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("PRIX"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATE_S"));
        return model;
}
