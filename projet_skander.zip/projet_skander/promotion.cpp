#include "promotion.h"

promotion::promotion()
{

}
promotion::promotion(QString id,int score)
{
    this->id_promo = id;
    this->score = score;
}
bool promotion::ajouter_promo()
{
    QSqlQuery query;
    QString res= QString::number(score);

    query.prepare("INSERT INTO promotions (ID_promotion,score) "
                        "VALUES (:ID_promotion,:score)");

    query.bindValue(":ID_promotion", id_promo);
    query.bindValue(":score", res);
    return  query.exec();

}
bool promotion::supprimer_prom(int idd)
{
    QSqlQuery query;
    QString res= QString::number(idd);
    query.prepare("Delete from promotions where ID_promotion = :id");
    query.bindValue(":id", res);
    return    query.exec();
}
QSqlQueryModel * promotion::afficher_prom()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from promotions");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_promotions"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("score"));

    return model;
}
