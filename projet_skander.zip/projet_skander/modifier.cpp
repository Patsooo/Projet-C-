#include "modifier.h"
#include "ui_modifier.h"
#include "documents.h"
#include "gestion_doc.h"
#include <QMessageBox>
modifier::modifier(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::modifier)
{
    ui->setupUi(this);
}

modifier::~modifier()
{
    delete ui;
}

void modifier::on_pushButton_clicked()
{
  int ID = ui->id_mod->text().toInt();
  QString TYPE= ui->type_mod->text();
  QString TITRE= ui->titre_mod->text();
  double PRIX = ui->prix_mod->text().toDouble();
  QDate date = ui->date_mod->date();
    documents d;

  bool test=d.modifier_doc(ID,TYPE,TITRE,PRIX,date);

  if(test)
  {
      //ui->table_doc->setModel(tmpdocuments.afficher_doc());
        QMessageBox::information(nullptr, QObject::tr("modifier un document"),
                  QObject::tr("Document modifier.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
  }
}

void modifier::on_retour_clicked()
{
    gestion_doc g;
    g.show();
    modifier::hide();
    g.exec();
}
