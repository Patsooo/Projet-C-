#ifndef AFFICHER_DOC_H
#define AFFICHER_DOC_H

#include <QDialog>
#include "documents.h"
namespace Ui {
class afficher_doc;
}

class afficher_doc : public QDialog
{
    Q_OBJECT

public:
    explicit afficher_doc(QWidget *parent = nullptr);
    ~afficher_doc();

private slots:
    void on_pushButton_clicked();

    void on_t_clicked();

    void on_r_clicked();

private:
    Ui::afficher_doc *ui;
    documents tmpdocuments;
};

#endif // AFFICHER_DOC_H
