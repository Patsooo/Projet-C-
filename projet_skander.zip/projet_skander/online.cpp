#include "online.h"

online::online()
{
    type_online="" ;
    source="" ;
    resume="";
}
online::online(QString a,QString b,QString c)
{
    this->type_online=a;
    this->source=b;
    this->resume=c;
}
