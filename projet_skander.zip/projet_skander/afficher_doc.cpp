#include "afficher_doc.h"
#include "ui_afficher_doc.h"
#include "documents.h"
#include "gestion_doc.h"
afficher_doc::afficher_doc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::afficher_doc)
{
    ui->setupUi(this);
    ui->table->setModel(tmpdocuments.afficher_doc());
}

afficher_doc::~afficher_doc()
{
    delete ui;
}

void afficher_doc::on_pushButton_clicked()
{
    gestion_doc g;
    g.show();
    afficher_doc::hide();
    g.exec();
}

void afficher_doc::on_t_clicked()
{
   ui->table->setModel(tmpdocuments.tri_doc());
}

void afficher_doc::on_r_clicked()
{
    int id = ui->a->text().toInt();
    ui->table->setModel(tmpdocuments.rechercher_doc(id));
}
