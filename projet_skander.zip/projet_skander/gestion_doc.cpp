#include "gestion_doc.h"
#include "ui_gestion_doc.h"
#include "documents.h"
#include <QMessageBox>
#include "ajouter_doc.h"
#include "gestion_doc.h"
#include "supprimer_doc.h"
#include "afficher_doc.h"
#include "modifier.h"
#include "mainwindow.h"

gestion_doc::gestion_doc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::gestion_doc)
{
    ui->setupUi(this);
}

gestion_doc::~gestion_doc()
{
    delete ui;
}

void gestion_doc::on_ajouter_clicked()
{
    ajouter_doc a;
    a.show();
    gestion_doc::hide();
    a.exec();
}

void gestion_doc::on_modifier_clicked()
{
    modifier m;
    m.show();
    gestion_doc::hide();
    m.exec();
}

void gestion_doc::on_supprimer_clicked()
{
    supprimer_doc s;
    s.show();
    gestion_doc::hide();
    s.exec();
}

void gestion_doc::on_afficher_clicked()
{
    afficher_doc a;
    a.show();
    gestion_doc::hide();
    a.exec();
}

void gestion_doc::on_pushButton_clicked()
{
    MainWindow m;
    gestion_doc::hide();
    m.show();
}
