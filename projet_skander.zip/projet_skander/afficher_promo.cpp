#include "afficher_promo.h"
#include "ui_afficher_promo.h"


afficher_promo::afficher_promo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::afficher_promo)
{
    ui->setupUi(this);
    ui->tabpromo->setModel(tmppromotions.afficher_prom());
}

afficher_promo::~afficher_promo()
{
    delete ui;
}
