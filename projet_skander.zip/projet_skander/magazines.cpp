#include "magazines.h"


magazines::magazines()
{
    sujet="" ;
    feedback="" ;
}
magazines::magazines(QString a,QString b)
{
    this->sujet=a;
    this->feedback=b;
}

