#include "autres_produits.h"

/*autres_produits::autres_produits()
{
type_produit="";
nb_produit=0;
}

autres_produits::autres_produits(QString a,int b)
{
    this->type_produit=a;
    this->nb_produit=b;
}*/
