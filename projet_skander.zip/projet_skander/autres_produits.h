#ifndef AUTRES_PRODUITS_H
#define AUTRES_PRODUITS_H


class autres_produits
{
public:
    autres_produits();
};

#endif // AUTRES_PRODUITS_H