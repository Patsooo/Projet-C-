#ifndef MAGAZINES_H
#define MAGAZINES_H
#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QString>
#include <QDate>
#include "documents.h"

class magazines: public documents
{
private:
    //QDate date_parution ;*/
    QString sujet;
    QString feedback ;

public:
    magazines();
    magazines(QString,QString);
};

#endif // MAGAZINES_H
