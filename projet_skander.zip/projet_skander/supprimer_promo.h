#ifndef SUPPRIMER_PROMO_H
#define SUPPRIMER_PROMO_H

#include <QDialog>
#include "promotion.h"
namespace Ui {
class supprimer_promo;
}

class supprimer_promo : public QDialog
{
    Q_OBJECT

public:
    explicit supprimer_promo(QWidget *parent = nullptr);
    ~supprimer_promo();

private slots:
    void on_supprimer_promo_2_clicked();

private:
    Ui::supprimer_promo *ui;
    promotion tmppromotions;
};

#endif // SUPPRIMER_PROMO_H
