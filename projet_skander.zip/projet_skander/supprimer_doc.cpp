#include "supprimer_doc.h"
#include "ui_supprimer_doc.h"
#include "documents.h"
#include"gestion_doc.h"
#include <QMessageBox>

supprimer_doc::supprimer_doc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::supprimer_doc)
{
    ui->setupUi(this);
}

supprimer_doc::~supprimer_doc()
{
    delete ui;
}

void supprimer_doc::on_supprimer_clicked()
{
    int id = ui->id_supp->text().toInt();
    bool test=tmpdocuments.supprimer_doc(id);
    if(test)
    {
        //ui->table->setModel(tmpdocuments.afficher_doc());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un document"),
                    QObject::tr("document supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un document"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void supprimer_doc::on_pushButton_clicked()
{
    gestion_doc g;
    g.show();
    supprimer_doc::hide();
    g.exec();
}
