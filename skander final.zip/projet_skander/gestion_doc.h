#ifndef GESTION_DOC_H
#define GESTION_DOC_H

#include <QDialog>

namespace Ui {
class gestion_doc;
}

class gestion_doc : public QDialog
{
    Q_OBJECT

public:
    explicit gestion_doc(QWidget *parent = nullptr);
    ~gestion_doc();

private slots:
    void on_ajouter_clicked();

    void on_modifier_clicked();

    void on_supprimer_clicked();

    void on_afficher_clicked();

    void on_pushButton_clicked();

private:
    Ui::gestion_doc *ui;
};

#endif // GESTION_DOC_H
