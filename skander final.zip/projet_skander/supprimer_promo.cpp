#include "supprimer_promo.h"
#include "ui_supprimer_promo.h"
#include "QMessageBox"
#include "gestion_promo.h"

supprimer_promo::supprimer_promo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::supprimer_promo)
{
    ui->setupUi(this);
    QRegExp rx1("[0-9_.]+");
    QValidator *v2 = new QRegExpValidator(rx1,this);
    ui->promo_supp->setValidator(v2);
}

supprimer_promo::~supprimer_promo()
{
    delete ui;
}

void supprimer_promo::on_supprimer_promo_2_clicked()
{
    int id = ui->promo_supp->text().toInt();
    bool test=tmppromotions.supprimer_prom(id);
    if(test)
    {
        //ui->table->setModel(tmpdocuments.afficher_doc());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer une promotion"),
                    QObject::tr(" promotion supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer une promotion"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void supprimer_promo::on_retour_clicked()
{
    gestion_promo g;
    g.show();
    supprimer_promo::hide();
    g.exec();
}
