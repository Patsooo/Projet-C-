#ifndef GESTION_PROMO_H
#define GESTION_PROMO_H

#include <QDialog>

namespace Ui {
class gestion_promo;
}

class gestion_promo : public QDialog
{
    Q_OBJECT

public:
    explicit gestion_promo(QWidget *parent = nullptr);
    ~gestion_promo();

private slots:
    void on_ajouter_clicked();

    void on_supprimer_clicked();

    void on_afficher_clicked();

private:
    Ui::gestion_promo *ui;
};

#endif // GESTION_PROMO_H
