#ifndef PROMOTION_H
#define PROMOTION_H

#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QString>
class promotion
{
private:
    QString id_promo;
    int score;
public:
    promotion();
    promotion(QString,int);
    bool ajouter_promo();
    bool supprimer_prom(int idd);
    QSqlQueryModel * afficher_prom();
    QSqlQueryModel * tri_pro();
    QSqlQueryModel * rechercher_pro(int a);

};

#endif // PROMOTION_H
