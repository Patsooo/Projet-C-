#include "ajouter_promo.h"
#include "ui_ajouter_promo.h"
#include "promotion.h"
#include <QMessageBox>
#include "gestion_promo.h"

ajouter_promo::ajouter_promo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ajouter_promo)
{
    ui->setupUi(this);
}

ajouter_promo::~ajouter_promo()
{
    delete ui;
    QRegExp rx("[A-Za-z_]+");
    QRegExp rx1("[0-9_.]+");
    QValidator *v2 = new QRegExpValidator(rx1,this);
    ui->id_promo->setValidator(v2);
    ui->score->setValidator(v2);

}

void ajouter_promo::on_ajouter_promo_2_clicked()
{
    int score = ui->score->text().toInt();
    QString id= ui->id_promo->text();

    promotion p (id,score);
    bool test=p.ajouter_promo();

      if(test)
      {
          //ui->table_doc->setModel(tmpdocuments.afficher_doc());
            QMessageBox::information(nullptr, QObject::tr("Ajouter un promotiont"),
                      QObject::tr("promotion ajouté.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
      }
}

void ajouter_promo::on_pushButton_clicked()
{
   gestion_promo g;
   g.show();
   ajouter_promo::hide();
   g.exec();
}
