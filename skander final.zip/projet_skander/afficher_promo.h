#ifndef AFFICHER_PROMO_H
#define AFFICHER_PROMO_H

#include <QDialog>
#include "promotion.h"
namespace Ui {
class afficher_promo;
}

class afficher_promo : public QDialog
{
    Q_OBJECT

public:
    explicit afficher_promo(QWidget *parent = nullptr);
    ~afficher_promo();

private slots:
    void on_retour_clicked();

    void on_tri_clicked();

private:
    Ui::afficher_promo *ui;
    promotion tmppromotions;
};

#endif // AFFICHER_PROMO_H
