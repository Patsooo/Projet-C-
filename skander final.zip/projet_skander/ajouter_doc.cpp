#include "ajouter_doc.h"
#include "ui_ajouter_doc.h"
#include <QMessageBox>
#include "documents.h"
#include "mainwindow.h"
#include"gestion_doc.h"
ajouter_doc::ajouter_doc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ajouter_doc)
{
    ui->setupUi(this);
    QDate d;
    QRegExp rx("[A-Za-z_]+");
    QRegExp rx1("[0-9_.]+");
    QValidator *v1 = new QRegExpValidator(rx,this);
    QValidator *v2 = new QRegExpValidator(rx1,this);
    ui->id->setValidator(v2);
    ui->type->setValidator(v1);
    ui->prix->setValidator(v2);
    ui->titre->setValidator(v1);
    ui->date->setDate(d.currentDate());
}

ajouter_doc::~ajouter_doc()
{
    delete ui;
}

void ajouter_doc::on_ajouter_clicked()
{
    int ID = ui->id->text().toInt();
    QString TYPE= ui->type->text();
    QString TITRE= ui->titre->text();
    double PRIX = ui->prix->text().toDouble();
    QDate date =ui->date->date();
    documents d (ID,TYPE,TITRE,PRIX,date);
    bool test=d.ajouter_doc();

      if(test)
      {
          //ui->table_doc->setModel(tmpdocuments.afficher_doc());
            QMessageBox::information(nullptr, QObject::tr("Ajouter un document"),
                      QObject::tr("Document ajouté.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
      }
}

void ajouter_doc::on_retour_clicked()
{
    gestion_doc g;
    g.show();
    ajouter_doc::hide();
    g.exec();
}

