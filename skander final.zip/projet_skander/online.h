#ifndef ONLINE_H
#define ONLINE_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QString>
#include "documents.h"


class online : public documents
{
private :
    QString type_online ;
    QString source ;
    QString resume;
public:
    online();
    online(QString,QString,QString);
};

#endif // ONLINE_H
