#ifndef AJOUTER_PROMO_H
#define AJOUTER_PROMO_H

#include <QDialog>

namespace Ui {
class ajouter_promo;
}

class ajouter_promo : public QDialog
{
    Q_OBJECT

public:
    explicit ajouter_promo(QWidget *parent = nullptr);
    ~ajouter_promo();

private slots:
    void on_ajouter_promo_2_clicked();

    void on_pushButton_clicked();

    void on_retour_clicked();

private:
    Ui::ajouter_promo *ui;
};

#endif // AJOUTER_PROMO_H
