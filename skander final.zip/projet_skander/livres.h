#ifndef LIVRES_H
#define LIVRES_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QString>
#include "documents.h"
class livres : public documents
{
private:
    QString genre ;
    QString localisation ;
    int note ;


public:
    livres();
    livres(QString,QString,int);
};

#endif // LIVRES_H
