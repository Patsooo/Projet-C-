#include "livres.h"


livres::livres()
{
    genre="" ;
    localisation="" ;
    note=0 ;
}
livres::livres(QString a,QString b ,int c)
{
    this->genre=a;
    this->localisation=b;
    this->note=c;
}
