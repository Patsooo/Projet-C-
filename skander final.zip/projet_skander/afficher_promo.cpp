#include "afficher_promo.h"
#include "ui_afficher_promo.h"
#include"gestion_promo.h"


afficher_promo::afficher_promo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::afficher_promo)
{
    ui->setupUi(this);
    ui->tabpromo->setModel(tmppromotions.afficher_prom());
}

afficher_promo::~afficher_promo()
{
    delete ui;
}

void afficher_promo::on_retour_clicked()
{
    gestion_promo g;
    g.show();
    afficher_promo::hide();
    g.exec();
}

void afficher_promo::on_tri_clicked()
{

}
