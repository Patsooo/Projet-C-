#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "documents.h"
#include <QMessageBox>
#include "ajouter_doc.h"
#include "gestion_doc.h"
#include "gestion_promo.h"
#include "supprimer_doc.h"
#include "afficher_doc.h"
#include "modifier.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
  // ui->table_doc->setModel(tmpdocuments.afficher_doc());
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_gestiondoc_clicked()
{
    gestion_doc g;
    g.show();
    MainWindow::hide();
    g.exec();
}



void MainWindow::on_gestionpro_clicked()
{
    gestion_promo g;
    g.show();
    MainWindow::hide();
    g.exec();
}
