#ifndef AJOUTER_DOC_H
#define AJOUTER_DOC_H

#include <QDialog>

namespace Ui {
class ajouter_doc;
}

class ajouter_doc : public QDialog
{
    Q_OBJECT

public:
    explicit ajouter_doc(QWidget *parent = nullptr);
    ~ajouter_doc();

private slots:
    void on_ajouter_clicked();

    void on_retour_clicked();

private:
    Ui::ajouter_doc *ui;
};

#endif // AJOUTER_DOC_H
