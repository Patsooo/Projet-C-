#include "gestion_promo.h"
#include "ui_gestion_promo.h"
#include "ajouter_promo.h"
#include "supprimer_promo.h"
#include "afficher_promo.h"
gestion_promo::gestion_promo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::gestion_promo)
{
    ui->setupUi(this);
}

gestion_promo::~gestion_promo()
{
    delete ui;
}

void gestion_promo::on_ajouter_clicked()
{
    ajouter_promo a;
    a.show();
    gestion_promo::hide();
    a.exec();
}

void gestion_promo::on_supprimer_clicked()
{
    supprimer_promo s;
    s.show();
    gestion_promo::hide();
    s.exec();
}

void gestion_promo::on_afficher_clicked()
{
    afficher_promo a;
a.show();
gestion_promo::hide();
a.exec();
}
