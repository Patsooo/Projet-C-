#ifndef SUPPRIMER_DOC_H
#define SUPPRIMER_DOC_H

#include <QDialog>
#include "documents.h"
namespace Ui {
class supprimer_doc;
}

class supprimer_doc : public QDialog
{
    Q_OBJECT

public:
    explicit supprimer_doc(QWidget *parent = nullptr);
    ~supprimer_doc();

private slots:
    void on_supprimer_clicked();

    void on_pushButton_clicked();

private:
    Ui::supprimer_doc *ui;
    documents tmpdocuments;
};

#endif // SUPPRIMER_DOC_H
