#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "id_dep.h"
#include "id_bloc.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{hide();
    id_dep id_dep;
    id_dep.setModal(true);
    id_dep.exec();

}

void MainWindow::on_pushButton_3_clicked()
{
    hide();
        id_bloc id_dep;
        id_dep.setModal(true);
        id_dep.exec();
}
