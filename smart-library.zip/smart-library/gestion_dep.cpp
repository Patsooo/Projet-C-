#include "gestion_dep.h"
#include "ui_gestion_dep.h"
#include "id_dep.h"
#include "ajou_dep.h"
#include "affich_deo.h"
#include "modif_dep.h"
#include "sup_dep.h"
gestion_dep::gestion_dep(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::gestion_dep)
{
    ui->setupUi(this);
}

gestion_dep::~gestion_dep()
{
    delete ui;
}

void gestion_dep::on_pushButton_clicked()
{
    hide();
    auto mm = new id_dep();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void gestion_dep::on_pushButton_ajouter_clicked()
{
    hide();
         ajou_dep x;
          x.setModal(true);
          x.exec();
}

void gestion_dep::on_pushButton_ajouter_2_clicked()
{
    hide();
         affich_deo x;
          x.setModal(true);
          x.exec();
}

void gestion_dep::on_pushButton_ajouter_4_clicked()
{
    hide();
         modif_dep x;
          x.setModal(true);
          x.exec();
}

void gestion_dep::on_pushButton_ajouter_3_clicked()
{  hide();
    sup_dep x;
     x.setModal(true);
     x.exec();
    
}


