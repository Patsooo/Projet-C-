#include "gestion_bloc.h"
#include "ui_gestion_bloc.h"
#include "id_bloc.h"
#include "ajou_bloc.h"
#include "affich_bloc.h"
#include "sup_bloc.h"
#include "modif_bloc.h"
gestion_bloc::gestion_bloc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::gestion_bloc)
{
    ui->setupUi(this);
}

gestion_bloc::~gestion_bloc()
{
    delete ui;
}

void gestion_bloc::on_pushButton_clicked()
{
    hide();
    auto mm = new id_bloc();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void gestion_bloc::on_pushButton_ajouter_clicked()
{
    hide();
         ajou_bloc x;
          x.setModal(true);
          x.exec();
}


void gestion_bloc::on_pushButton_ajouter_2_clicked()
{
        hide();affich_bloc x;
    x.setModal(true);
    x.exec();

}

void gestion_bloc::on_pushButton_ajouter_3_clicked()
{    hide();
    sup_bloc x;
        x.setModal(true);
        x.exec();
}



void gestion_bloc::on_pushButton_ajouter_5_clicked()
{
    hide();
      modif_bloc x;
           x.setModal(true);
           x.exec();
}
