#include "id_dep.h"
#include "ui_id_dep.h"
#include <QString>
#include<QMessageBox>
#include "gestion_dep.h"
#include "mainwindow.h"
id_dep::id_dep(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::id_dep)
{
    ui->setupUi(this);
}

id_dep::~id_dep()
{
    delete ui;
}

void id_dep::on_pushButton_login_clicked()
{
    QString username=ui->lineEdit_user_name->text();
    QString password=ui->lineEdit_password->text();
    if (username=="kenza"&&password=="kenza")
{        hide();
       gestion_dep x;
        x.setModal(true);
        x.exec();

  }else if (username!="kenza"&&password=="kenza")
    {QMessageBox::warning(this,"ERREUR","Le login que vous utilsez est incorrecte !!!"); }
    else if (username=="kenza"&&password!="kenza")
        {QMessageBox::warning(this,"ERREUR","Le password que vous utilsez est incorrecte !!!"); }


}

void id_dep::on_pushButton_clicked()
{
       hide();
       auto mm = new MainWindow();
       mm->setAttribute(Qt::WA_DeleteOnClose);
       mm->show();
}
