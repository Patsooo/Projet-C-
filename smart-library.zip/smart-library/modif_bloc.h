#ifndef MODIF_BLOC_H
#define MODIF_BLOC_H

#include <QDialog>
#include "bloc.h"
namespace Ui {
class modif_bloc;
}

class modif_bloc : public QDialog
{
    Q_OBJECT

public:
    explicit modif_bloc(QWidget *parent = nullptr);
    ~modif_bloc();

private slots:

    void on_pushButton_clicked();

    void on_pushButton_login_clicked();

private:
    Ui::modif_bloc *ui;
    bloc tmpbloc;
};

#endif // MODIF_BLOC_H
