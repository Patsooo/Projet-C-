#include "ajou_dep.h"
#include "ui_ajou_dep.h"
#include "gestion_dep.h"
#include "departement.h"
#include<QDate>
#include <QMessageBox>
#include"affich_deo.h"
#include "ajou_dep.h"
#include "bloc.h"
ajou_dep::ajou_dep(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ajou_dep)
{
    ui->setupUi(this);
}


ajou_dep::~ajou_dep()
{
    delete ui;
}

void ajou_dep::on_pushButton_clicked()
{
    hide();
    auto mm = new gestion_dep();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void ajou_dep::on_pushButton_login_clicked()
{
    QString nom= ui->lineEdit_nom->text();
    int etage = ui->lineEdit_etage->text().toInt();
    int salle = ui->lineEdit_salle->text().toInt();
   QString bloc=ui->lineEdit_bloc->text();
   Departement d(nom,etage,salle,bloc);
 d.ajouter();

  bool verif= d.modifier_rech(bloc);
if (verif){QMessageBox::information(nullptr, QObject::tr("Ajouter un departement dans bloc"),
                                 QObject::tr("departement ajouté. dans bloc \ndepartement ajouté. dans bloc \ndepartement ajouté. dans bloc \ndepartement ajouté. dans bloc \n\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);}
 else
       QMessageBox::critical(nullptr, QObject::tr("Ajouter un departement"),
                   QObject::tr("Erreur !CE BLOC n'existe pas.\nErreur !CE BLOC n'existe pas.\nErreur !CE BLOC n'existe pas.\nErreur !CE BLOC n'existe pas.\n"
                               "Click Cancel to exit."), QMessageBox::Cancel);

}
