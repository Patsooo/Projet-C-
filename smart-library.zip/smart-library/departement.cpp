#include "departement.h"
#include<QSqlQuery>
#include<QString>
#include<QSqlQueryModel>
#include<QVariant>
bool Departement::ajouter()
{QSqlQuery query;
QString res=QString::number(etage);
QString res1=QString::number(salle);
query.prepare("INSERT INTO Departement (nom,etage,salle, bloc) "
              "VALUES (:nom, :etage, :salle, :bloc)");
query.bindValue(":etage", res);
query.bindValue(":salle", res1);
query.bindValue(":bloc", bloc);
query.bindValue(":nom", nom);

return  query.exec();
}
QSqlQueryModel * Departement::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from departement");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("etge"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("salle"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("bloc "));
    return model;
}

QSqlQueryModel * Departement ::trier_nom()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from departement ORDER BY nom");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("etage"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("salle"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("bloc"));
        return model;
}
QSqlQueryModel * Departement ::trier_etage()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from departement ORDER BY etage");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("etage"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("salle"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("bloc"));
        return model;
}
QSqlQueryModel * Departement ::trier_salle()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from departement ORDER BY salle");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("etage"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("salle"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("bloc"));
        return model;
}
QSqlQueryModel * Departement ::trier_bloc()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from departement ORDER BY bloc");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("etage"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("salle"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("bloc"));
        return model;
}
bool Departement::modifier(QString nom,int etage,int salle,QString bloc){
    QSqlQuery query;
    QString res=QString::number(etage);
    QString res1=QString::number(salle);
    query.prepare("update departement set nom=:nom,etage=:etage ,salle=:salle ,bloc=:bloc where nom = :nom");
    query.bindValue(":etage", res);
    query.bindValue(":salle", res1);
    query.bindValue(":nom", nom);
    query.bindValue(":bloc", bloc);
    return query.exec();
}
bool Departement::rech(QString n){
    QSqlQuery query;
    query.prepare("select * from departement where nom = :nom");
    query.bindValue(":nom", n);
    return query.exec();
}
QSqlQueryModel *Departement ::rechercher_nom(QString nomc)
{


QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from departement where nom like '"+nomc+"' ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("etage"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("salle"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("bloc"));
return model;
}
QSqlQueryModel *Departement ::rechercher_bloc(QString x)
{


QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from departement where bloc like '"+x+"' ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("etage"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("salle"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("bloc"));
return model;
}
bool Departement::supprimer_nom(QString x)
{
QSqlQuery query;

query.prepare("Delete from departement where nom = :nom ");
query.bindValue(":nom", x);
return    query.exec();
}
bool Departement::supprimer_bloc(QString x)
{
QSqlQuery query;

query.prepare("Delete from departement where bloc = :bloc ");
query.bindValue(":bloc", x);
return    query.exec();
}
bool Departement::modifier_rech(QString x){
    QSqlQuery query;

    query.prepare("update bloc set nb_dep=nb_dep+1 where nom = :nom");
    query.bindValue(":nom", x);

    return query.exec();
}
bool Departement::modifier_rech2(QString x){
    QSqlQuery query;

    query.prepare("update bloc set nb_dep=nb_dep-1 where nom = :nom");
    query.bindValue(":nom", x);

    return query.exec();
}
