#ifndef AFFICH_BLOC_H
#define AFFICH_BLOC_H

#include <QDialog>
#include "bloc.h"
namespace Ui {
class affich_bloc;
}

class affich_bloc : public QDialog
{
    Q_OBJECT

public:
    explicit affich_bloc(QWidget *parent = nullptr);
    ~affich_bloc();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_login_7_clicked();

    void on_pushButton_login_8_clicked();

    void on_pushButton_login_6_clicked();

    void on_pushButton_login_5_clicked();

private:
    Ui::affich_bloc *ui;
    bloc tmpbloc;
};

#endif // AFFICH_BLOC_H
