#ifndef ID_BLOC_H
#define ID_BLOC_H

#include <QDialog>

namespace Ui {
class id_bloc;
}

class id_bloc : public QDialog
{
    Q_OBJECT

public:
    explicit id_bloc(QWidget *parent = nullptr);
    ~id_bloc();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_login_clicked();

private:
    Ui::id_bloc *ui;
};

#endif // ID_BLOC_H
