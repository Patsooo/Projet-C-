#include "affich_bloc.h"
#include "ui_affich_bloc.h"
#include "gestion_bloc.h"
#include "bloc.h"
#include <QMessageBox>
affich_bloc::affich_bloc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::affich_bloc)
{
    ui->setupUi(this);
    ui->tabdepartement_2->setModel(tmpbloc.afficher());

}

affich_bloc::~affich_bloc()
{
    delete ui;
}

void affich_bloc::on_pushButton_clicked()
{
    hide();
    auto mm = new gestion_bloc();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void affich_bloc::on_pushButton_login_7_clicked()
{
    bloc c;

        if(c.trier_nom()){

                ui->tabdepartement_2->setModel(tmpbloc.trier_nom());
                QMessageBox::information(nullptr, QObject::tr("trier bloc"),
                            QObject::tr("bloc trier.\n"
                                        "Voulez-vous enregistrer les modifications ?"),
                                   QMessageBox::Save
                                   | QMessageBox::Cancel,
                                  QMessageBox::Save);

            }
            else
                QMessageBox::critical(nullptr, QObject::tr("trier bloc"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
}

void affich_bloc::on_pushButton_login_8_clicked()
{
    bloc c;

        if(c.trier_nb_dep()){

                ui->tabdepartement_2->setModel(tmpbloc.trier_nb_dep());
                QMessageBox::information(nullptr, QObject::tr("trier bloc"),
                            QObject::tr("bloc trier.\n"
                                        "Voulez-vous enregistrer les modifications ?"),
                                   QMessageBox::Save
                                   | QMessageBox::Cancel,
                                  QMessageBox::Save);

            }
            else
                QMessageBox::critical(nullptr, QObject::tr("trier bloc"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
}

void affich_bloc::on_pushButton_login_6_clicked()
{
   int nb_dep = ui->lineEdit_2->text().toInt();
    ui->tabdepartement_2->setModel(tmpbloc.rechercher_nb_dep(nb_dep));

    bool test=tmpbloc.rechercher_nb_dep(nb_dep);
    if (!test)
    {
    QMessageBox::information(nullptr, QObject::tr("Rechercher un bloc"),
                      QObject::tr(" bloc n'existe pas .\n"
                                  "Try again."), QMessageBox::Retry);
}}

void affich_bloc::on_pushButton_login_5_clicked()
{
    QString nomc =ui->lineEdit->text();  /*->currentText();*/

    ui->tabdepartement_2->setModel(tmpbloc.rechercher_nom(nomc));

    bool test=tmpbloc.rechercher_nom(nomc);
    if (!test)
    {
    QMessageBox::information(nullptr, QObject::tr("Rechercher un bloc"),
                      QObject::tr(" bloc n'existe pas .\n"
                                  "Try again."), QMessageBox::Retry);
   }
}
