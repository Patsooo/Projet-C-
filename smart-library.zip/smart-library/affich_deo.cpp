#include "affich_deo.h"
#include "ui_affich_deo.h"
#include "gestion_dep.h"
#include<QMessageBox>
#include <QString>
affich_deo::affich_deo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::affich_deo)
{
    ui->setupUi(this);
     ui->tabdepartement->setModel(tmpDepartement.afficher());
}

affich_deo::~affich_deo()
{
    delete ui;
}

void affich_deo::on_pushButton_clicked()
{
    hide();
    auto mm = new gestion_dep();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void affich_deo::on_pushButton_login_3_clicked()
{
    Departement c;

        if(c.trier_nom()){

                ui->tabdepartement->setModel(tmpDepartement.trier_nom());
                QMessageBox::information(nullptr, QObject::tr("trier departement"),
                            QObject::tr("departement trier.\n"
                                        "Voulez-vous enregistrer les modifications ?"),
                                   QMessageBox::Save
                                   | QMessageBox::Cancel,
                                  QMessageBox::Save);

            }
            else
                QMessageBox::critical(nullptr, QObject::tr("trier departement"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
}

void affich_deo::on_pushButton_login_clicked()
{
    Departement c;

        if(c.trier_etage()){

                ui->tabdepartement->setModel(tmpDepartement.trier_etage());
                QMessageBox::information(nullptr, QObject::tr("trier departement"),
                            QObject::tr("departement trier.\n"
                                        "Voulez-vous enregistrer les modifications ?"),
                                   QMessageBox::Save
                                   | QMessageBox::Cancel,
                                  QMessageBox::Save);

            }
            else
                QMessageBox::critical(nullptr, QObject::tr("trier departement"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
}


void affich_deo::on_pushButton_login_2_clicked()
{
    Departement c;

        if(c.trier_salle()){

                ui->tabdepartement->setModel(tmpDepartement.trier_salle());
                QMessageBox::information(nullptr, QObject::tr("trier departement"),
                            QObject::tr("departement trier.\n"
                                        "Voulez-vous enregistrer les modifications ?"),
                                   QMessageBox::Save
                                   | QMessageBox::Cancel,
                                  QMessageBox::Save);

            }
            else
                QMessageBox::critical(nullptr, QObject::tr("trier departement"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
}

void affich_deo::on_pushButton_login_4_clicked()
{
    Departement c;

        if(c.trier_bloc()){

                ui->tabdepartement->setModel(tmpDepartement.trier_bloc());
                QMessageBox::information(nullptr, QObject::tr("trier departement"),
                            QObject::tr("departement trier.\n"
                                        "Voulez-vous enregistrer les modifications ?"),
                                   QMessageBox::Save
                                   | QMessageBox::Cancel,
                                  QMessageBox::Save);

            }
            else
                QMessageBox::critical(nullptr, QObject::tr("trier departement"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
}

void affich_deo::on_pushButton_login_5_clicked()
{
    QString nomc =ui->lineEdit->text();  /*->currentText();*/

    ui->tabdepartement->setModel(tmpDepartement.rechercher_nom(nomc));

    bool test=tmpDepartement.rechercher_nom(nomc);
    if (!test)
    {
    QMessageBox::information(nullptr, QObject::tr("Rechercher un departement"),
                      QObject::tr(" departement n'existe pas .\n"
                                  "Try again."), QMessageBox::Retry);
   }
}

 void affich_deo::on_pushButton_login_6_clicked()
{
    QString nomc =ui->lineEdit_2->text();  //->currentText();

    ui->tabdepartement->setModel(tmpDepartement.rechercher_bloc(nomc));

    bool test=tmpDepartement.rechercher_bloc(nomc);
    if (!test)
    {
    QMessageBox::information(nullptr, QObject::tr("Rechercher un departement"),
                      QObject::tr(" departement n'existe pas .\n"
                                  "Try again."), QMessageBox::Retry);
   }
}

