#ifndef AJOU_DEP_H
#define AJOU_DEP_H
#include <QDialog>
#include "bloc.h"
#include"departement.h"
namespace Ui {
class ajou_dep;
}

class ajou_dep : public QDialog
{
    Q_OBJECT

public:
    explicit ajou_dep(QWidget *parent = nullptr);
    ~ajou_dep();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_login_clicked();

private:
    Ui::ajou_dep *ui;
    bloc tmpbloc;

};

#endif // AJOU_DEP_H
