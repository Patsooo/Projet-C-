#include "modif_bloc.h"
#include "ui_modif_bloc.h"
#include "gestion_bloc.h"
#include "bloc.h"
#include <QMessageBox>
modif_bloc::modif_bloc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::modif_bloc)
{
    ui->setupUi(this);
}

modif_bloc::~modif_bloc()
{
    delete ui;
}



void modif_bloc::on_pushButton_clicked()
{
    hide();
    auto mm = new gestion_bloc();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void modif_bloc::on_pushButton_login_clicked()
{

    int nb_dep = ui->lineEdit_salle->text().toInt();

        QString nom= ui->lineEdit_nom->text();

        bloc d1;
            if(d1.rech(nom)){
                bool test = d1.modifier(nom,nb_dep);
                if(test){
                    ui->tabdepartement->setModel(tmpbloc.rechercher_nom(nom));

                 /*   QMessageBox::information(nullptr, QObject::tr("Modifier le departement"),
                                QObject::tr("departement modifié.\n"
                                            "Voulez-vous enregistrer les modifications ?"),
                                       QMessageBox::Save
                                       | QMessageBox::Cancel,
                                      QMessageBox::Save);*/

                }
                else
                    QMessageBox::critical(nullptr, QObject::tr("Modifier le departement"),
                                QObject::tr("Erreur !.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
            }
}
