#include "sup_dep.h"
#include "ui_sup_dep.h"
#include "gestion_dep.h"
#include <QMessageBox>
#include "departement.h"
#include "affich_deo.h"
sup_dep::sup_dep(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sup_dep)
{
    ui->setupUi(this);
}

sup_dep::~sup_dep()
{
    delete ui;
}

void sup_dep::on_pushButton_clicked()
{
    hide();
    auto mm = new gestion_dep();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}



void sup_dep::on_pushButton_login_6_clicked()
{
    QString nom = ui->lineEdit_2->text();
    bool test=tmpDepartement.supprimer_nom(nom);
    if(test)
    {//ui->tabdepartement->setModel(tmpDepartement.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un departement selon le nom"),
                    QObject::tr("departement supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un departement selon le nom"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void sup_dep::on_pushButton_login_7_clicked()
{
    {
        QString bloc = ui->lineEdit_3->text();
        bool test=tmpDepartement.supprimer_bloc(bloc);
        if(test)
        {//ui->tabdepartement->setModel(tmpDepartement.afficher());//refresh
            QMessageBox::information(nullptr, QObject::tr("Supprimer un departement selon le nom"),
                        QObject::tr("departement supprimé.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Supprimer un departement selon le nom"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
    }
}
