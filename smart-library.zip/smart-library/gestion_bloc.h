#ifndef GESTION_BLOC_H
#define GESTION_BLOC_H

#include <QDialog>

namespace Ui {
class gestion_bloc;
}

class gestion_bloc : public QDialog
{
    Q_OBJECT

public:
    explicit gestion_bloc(QWidget *parent = nullptr);
    ~gestion_bloc();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_ajouter_clicked();

    void on_pushButton_ajouter_2_clicked();

    void on_pushButton_ajouter_4_clicked();
    
    void on_pushButton_ajouter_3_clicked();

    void on_pushButton_ajouter_5_clicked();

private:
    Ui::gestion_bloc *ui;
};

#endif // GESTION_BLOC_H
