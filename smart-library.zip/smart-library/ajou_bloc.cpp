#include "ajou_bloc.h"
#include "ui_ajou_bloc.h"
#include "gestion_bloc.h"
#include <QMessageBox>
#include "bloc.h"
#include<QDate>
#include <QMessageBox>
#include"affich_bloc.h"

ajou_bloc::ajou_bloc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ajou_bloc)
{
    ui->setupUi(this);
}

ajou_bloc::~ajou_bloc()
{
    delete ui;
}

void ajou_bloc::on_pushButton_clicked()
{
    hide();
    auto mm = new gestion_bloc();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void ajou_bloc::on_pushButton_login_clicked()
{
    QString nom= ui->lineEdit_nom->text();
    int nb_dep = ui->lineEdit_salle->text().toInt();
    bloc d(nom,nb_dep);
    bool verifier=d.rech(nom);
    if(verifier)
    {
     bool test=d.ajouter2();
    if(test)

    {


    QMessageBox::information(nullptr, QObject::tr("Ajouter un bloc"),
                      QObject::tr("bloc ajouté.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
    }else
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un bloc"),
                    QObject::tr("EXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\nEXISTE\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }else
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un bloc"),
                    QObject::tr("Erreur !bloc existe.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}
