#ifndef AJOU_BLOC_H
#define AJOU_BLOC_H

#include <QDialog>
#include "bloc.h"
namespace Ui {
class ajou_bloc;
}

class ajou_bloc : public QDialog
{
    Q_OBJECT

public:
    explicit ajou_bloc(QWidget *parent = nullptr);
    ~ajou_bloc();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_login_clicked();

private:
    Ui::ajou_bloc *ui;
};

#endif // AJOU_BLOC_H
