#ifndef GESTION_DEP_H
#define GESTION_DEP_H

#include <QDialog>

namespace Ui {
class gestion_dep;
}

class gestion_dep : public QDialog
{
    Q_OBJECT

public:
    explicit gestion_dep(QWidget *parent = nullptr);
    ~gestion_dep();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_ajouter_clicked();

    void on_pushButton_ajouter_2_clicked();

    void on_pushButton_ajouter_4_clicked();

    void on_pushButton_ajouter_3_clicked();


    
private:
    Ui::gestion_dep *ui;
};

#endif // GESTION_DEP_H
