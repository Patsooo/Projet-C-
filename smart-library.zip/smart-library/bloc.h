#ifndef BLOC_H
#define BLOC_H
#include<QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class bloc
{ QString nom;
    int nb_dep;
public:
    bloc(){nom="";nb_dep=0;}
    bloc(QString nom,int nb_dep){this->nom=nom;this->nb_dep=nb_dep;}
    QString get_nom(){return nom;}
    int get_nb_dep(){return nb_dep;}
    void det_nb_dep(int x){nb_dep=x;}
    bool ajouter2();
    QSqlQueryModel * afficher();
    QSqlQueryModel * trier_nom();
    QSqlQueryModel * trier_nb_dep();
   QSqlQueryModel *rechercher_nom(QString );
QSqlQueryModel *rechercher_nb_dep(int );
bool modifier(QString,int);
bool supprimer(QString);


    bool rech(QString);

    ~bloc(){}
};

#endif // BLOC_H
