#include "sup_bloc.h"
#include "ui_sup_bloc.h"
#include "gestion_bloc.h"
#include<QMessageBox>
sup_bloc::sup_bloc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sup_bloc)
{
    ui->setupUi(this);
}

sup_bloc::~sup_bloc()
{
    delete ui;
}

void sup_bloc::on_pushButton_clicked()
{
    hide();
    auto mm = new gestion_bloc();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void sup_bloc::on_pushButton_login_6_clicked()
{
    QString nom = ui->lineEdit_2->text();
    bool test=tmpbloc.supprimer(nom);
    if(test)
    {//ui->tabdepartement->setModel(tmpDepartement.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un departement selon le nom"),
                    QObject::tr("departement supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un departement selon le nom"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}
