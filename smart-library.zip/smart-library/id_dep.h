#ifndef ID_DEP_H
#define ID_DEP_H

#include <QDialog>
#include<QMainWindow>

namespace Ui {
class id_dep;
}

class id_dep : public QDialog
{
    Q_OBJECT

public:
    explicit id_dep(QWidget *parent = nullptr);
    ~id_dep();

private slots:
    void on_pushButton_login_clicked();

    void on_pushButton_clicked();

private:
    Ui::id_dep *ui;
};

#endif // ID_DEP_H
