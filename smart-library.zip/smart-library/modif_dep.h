#ifndef MODIF_DEP_H
#define MODIF_DEP_H

#include <QDialog>
#include "departement.h"
namespace Ui {
class modif_dep;
}

class modif_dep : public QDialog
{
    Q_OBJECT

public:
    explicit modif_dep(QWidget *parent = nullptr);
    ~modif_dep();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_login_clicked();

private:
    Ui::modif_dep *ui;
    Departement tmpDepartement;
};

#endif // MODIF_DEP_H
