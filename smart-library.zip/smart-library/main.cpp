#include "mainwindow.h"
#include "connexion.h"
#include <QApplication>
#include<QString>
#include<QIcon>
#include<QtDebug>
#include<QMessageBox>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    connexion c;
    bool test=c.ouvrirconnexion();
    if(test)
    {w.show();

        /*QMessageBox::information(nullptr, QObject::tr("database is open"),
                    QObject::tr("connection avec succés.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);*/

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("database is not open"),
                    QObject::tr("connection failed.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

      return a.exec();}
   // w.setWindowTitle("Gestion Departement/Bloc");
    //w.resize(1300,693);w.show();


