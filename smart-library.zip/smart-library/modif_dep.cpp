#include "modif_dep.h"
#include "ui_modif_dep.h"
#include "gestion_dep.h"
#include "departement.h"
#include <QMessageBox>
#include "affich_deo.h"
modif_dep::modif_dep(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::modif_dep)
{
    ui->setupUi(this);
}

modif_dep::~modif_dep()
{
    delete ui;
}

void modif_dep::on_pushButton_clicked()
{
    hide();
    auto mm = new gestion_dep();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void modif_dep::on_pushButton_login_clicked()
{
    int etage = ui->lineEdit_etage->text().toInt();
    int salle = ui->lineEdit_salle->text().toInt();

        QString nom= ui->lineEdit_nom->text();
        QString bloc= ui->lineEdit_bloc->text();

        Departement d1;
            if(d1.rech(nom)){
                bool test = d1.modifier(nom,etage,salle,bloc);
                if(test){
                    ui->tabdepartement->setModel(tmpDepartement.rechercher_nom(nom));

                 /*   QMessageBox::information(nullptr, QObject::tr("Modifier le departement"),
                                QObject::tr("departement modifié.\n"
                                            "Voulez-vous enregistrer les modifications ?"),
                                       QMessageBox::Save
                                       | QMessageBox::Cancel,
                                      QMessageBox::Save);*/

                }
                else
                    QMessageBox::critical(nullptr, QObject::tr("Modifier le departement"),
                                QObject::tr("Erreur !.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
            }
}
