#ifndef DEPARTEMENT_H
#define DEPARTEMENT_H
#include<QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include "bloc.h"
class Departement
{QString nom,bloc;
    int etage,salle;
public:
    Departement(){nom="";bloc="";etage=0;salle=0;}
    Departement(QString nom,int etage,int salle,QString bloc){this->nom=nom;this->bloc=bloc;this->etage=etage;this->salle=salle;}
     QString get_bloc(){return bloc;}
     bool ajouter();
     QSqlQueryModel * afficher();

     QSqlQueryModel * trier_nom();
     QSqlQueryModel * trier_etage();
     QSqlQueryModel * trier_salle();
     QSqlQueryModel * trier_bloc();
bool modifier(QString,int,int ,QString);
bool rech(QString);
QSqlQueryModel *rechercher_nom(QString );
QSqlQueryModel *rechercher_bloc(QString );
bool supprimer_nom(QString);
bool supprimer_bloc(QString);
bool modifier_rech(QString  );
bool modifier_rech2(QString  );

     ~Departement(){}
};

#endif // DEPARTEMENT_H
