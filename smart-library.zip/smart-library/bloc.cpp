#include "bloc.h"
#include<QSqlQuery>
#include<QString>
#include<QSqlQueryModel>
#include<QVariant>
bool bloc::ajouter2()
{QSqlQuery query;
    QString res=QString::number(nb_dep);

    query.prepare("INSERT INTO bloc (nom,nb_dep) "
                  "VALUES (:nom, :nb_dep)");
    query.bindValue(":nb_dep", res);

    query.bindValue(":nom", nom);

    return  query.exec();
}
QSqlQueryModel * bloc::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from bloc");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("nb_dep"));

    return model;
}
QSqlQueryModel * bloc ::trier_nom()
{
    QSqlQueryModel * model= new QSqlQueryModel();


    model->setQuery("select * from bloc ORDER BY nom");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("nb_dep"));
        return model;
}
bool bloc::rech(QString n){
    QSqlQuery query;
    query.prepare("select * from bloc where nom = :nom");
    query.bindValue(":nom", n);
    return query.exec();
}
QSqlQueryModel * bloc ::trier_nb_dep()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("select * from bloc ORDER BY nb_dep");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("nb_dep"));
        return model;
}
QSqlQueryModel *bloc ::rechercher_nom(QString nomc)
{


QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from bloc where nom like '"+nomc+"' ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("nb_dep"));
return model;
}
QSqlQueryModel *bloc ::rechercher_nb_dep(int nb)
{

QString res=QString::number(nb);
QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from bloc where nb_dep like '"+res+"' ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("nb_dep"));
return model;
}


bool bloc::modifier(QString nom,int nb_dep){
    QSqlQuery query;
    QString res=QString::number(nb_dep);

    query.prepare("update bloc set nom=:nom,nb_dep=:nb_dep where nom = :nom");
    query.bindValue(":nb_dep", res);

    query.bindValue(":nom", nom);

    return query.exec();
}
bool bloc::supprimer(QString x)
{
QSqlQuery query;

query.prepare("Delete from bloc where nom = :nom ");
query.bindValue(":nom", x);
return    query.exec();
}
