#include "id_bloc.h"
#include "ui_id_bloc.h"
#include "mainwindow.h"
#include <QMessageBox>
#include "gestion_bloc.h"
id_bloc::id_bloc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::id_bloc)
{
    ui->setupUi(this);
}

id_bloc::~id_bloc()
{
    delete ui;
}

void id_bloc::on_pushButton_clicked()
{
    hide();
    auto mm = new MainWindow();
    mm->setAttribute(Qt::WA_DeleteOnClose);
    mm->show();
}

void id_bloc::on_pushButton_login_clicked()
{
    QString username=ui->lineEdit_user_name->text();
    QString password=ui->lineEdit_password->text();
    if (username=="kenza"&&password=="kenza")
{        hide();
       gestion_bloc x;
        x.setModal(true);
        x.exec();

  }else if (username!="kenza"&&password=="kenza")
    {QMessageBox::warning(this,"ERREUR","Le login que vous utilsez est incorrecte !!!"); }
    else if (username=="kenza"&&password!="kenza")
        {QMessageBox::warning(this,"ERREUR","Le password que vous utilsez est incorrecte !!!"); }
}
